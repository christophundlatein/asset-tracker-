#!/usr/bin/env python3
"""Generate icon PNGs from SVG for the PWA."""
import subprocess, sys

svg = '''<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect width="512" height="512" rx="112" fill="#0D1117"/>
  <rect x="8" y="8" width="496" height="496" rx="104" stroke="#00E5A0" stroke-width="12" stroke-opacity="0.4"/>
  <!-- Grid lines -->
  <line x1="96" y1="384" x2="416" y2="384" stroke="#1E2D3D" stroke-width="8"/>
  <line x1="96" y1="304" x2="416" y2="304" stroke="#1E2D3D" stroke-width="8"/>
  <line x1="96" y1="224" x2="416" y2="224" stroke="#1E2D3D" stroke-width="8"/>
  <!-- Bars -->
  <rect x="104" y="280" width="48" height="104" rx="12" fill="#00E5A0" fill-opacity="0.5"/>
  <rect x="176" y="240" width="48" height="144" rx="12" fill="#00E5A0" fill-opacity="0.65"/>
  <rect x="248" y="176" width="48" height="208" rx="12" fill="#00E5A0"/>
  <rect x="320" y="216" width="48" height="168" rx="12" fill="#00E5A0" fill-opacity="0.8"/>
  <!-- Upper alert line -->
  <line x1="80" y1="192" x2="432" y2="192" stroke="#FF6B6B" stroke-width="10" stroke-dasharray="24 16"/>
  <!-- Lower alert line -->
  <line x1="80" y1="336" x2="432" y2="336" stroke="#FFB830" stroke-width="10" stroke-dasharray="24 16"/>
  <!-- Bell -->
  <circle cx="392" cy="120" r="48" fill="#0D1117"/>
  <path d="M392 92C372 92 356 106 356 124V140L348 148V152H436V148L428 140V124C428 106 412 92 392 92Z" fill="#FFB830"/>
  <path d="M380 154C380 160.6 385.4 166 392 166C398.6 166 404 160.6 404 154H380Z" fill="#FFB830"/>
</svg>'''

with open("/home/claude/asset-tracker-pwa/icon.svg", "w") as f:
    f.write(svg)

# Try cairosvg first, then rsvg-convert, then just copy svg as fallback
try:
    import cairosvg
    cairosvg.svg2png(bytestring=svg.encode(), write_to="/home/claude/asset-tracker-pwa/icon-512.png", output_width=512, output_height=512)
    cairosvg.svg2png(bytestring=svg.encode(), write_to="/home/claude/asset-tracker-pwa/icon-192.png", output_width=192, output_height=192)
    print("Icons created with cairosvg")
except ImportError:
    result = subprocess.run(["rsvg-convert", "-w", "512", "-h", "512", "-o", "/home/claude/asset-tracker-pwa/icon-512.png", "/home/claude/asset-tracker-pwa/icon.svg"], capture_output=True)
    if result.returncode == 0:
        subprocess.run(["rsvg-convert", "-w", "192", "-h", "192", "-o", "/home/claude/asset-tracker-pwa/icon-192.png", "/home/claude/asset-tracker-pwa/icon.svg"])
        print("Icons created with rsvg-convert")
    else:
        # Fallback: use Pillow to create a simple colored icon
        try:
            from PIL import Image, ImageDraw
            for size in [192, 512]:
                img = Image.new("RGBA", (size, size), (13, 17, 23, 255))
                draw = ImageDraw.Draw(img)
                r = int(size * 0.22)
                draw.rounded_rectangle([0,0,size-1,size-1], radius=r, fill=(13,17,23,255), outline=(0,229,160,60), width=max(2, size//60))
                # Bars
                bw = size // 11
                gap = size // 11
                colors_alpha = [128, 165, 255, 204]
                positions = [0.2, 0.34, 0.48, 0.62]
                heights = [0.27, 0.37, 0.53, 0.43]
                bottom = int(size * 0.77)
                for i, (pos, h, alpha) in enumerate(zip(positions, heights, [128,165,255,204])):
                    x = int(size * pos)
                    bar_h = int(size * h)
                    draw.rounded_rectangle([x, bottom-bar_h, x+bw, bottom], radius=4, fill=(0,229,160,alpha))
                # Alert lines
                draw.line([(int(size*0.15), int(size*0.37)), (int(size*0.85), int(size*0.37))], fill=(255,107,107,200), width=max(2,size//80))
                draw.line([(int(size*0.15), int(size*0.65)), (int(size*0.85), int(size*0.65))], fill=(255,184,48,200), width=max(2,size//80))
                img.save(f"/home/claude/asset-tracker-pwa/icon-{size}.png", "PNG")
            print("Icons created with Pillow")
        except Exception as ex:
            print(f"Pillow failed: {ex}")
